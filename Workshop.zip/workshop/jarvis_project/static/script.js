const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
let recognition;
let isListening = false;

// Initialize speech recognition if available
if (SpeechRecognition) {
    recognition = new SpeechRecognition();
    recognition.continuous = false;
    recognition.interimResults = false;
    recognition.lang = 'en-US';
}

const userInput = document.getElementById('user-input');
const voiceBtn = document.getElementById('voice-btn');
const sendBtn = document.getElementById('send-btn');
const clearBtn = document.getElementById('clr-btn');
const chatBox = document.getElementById('chat-box');

// Update time display
function updateTime() {
    const now = new Date();
    const timeDisplay = document.getElementById('time-display');
    timeDisplay.textContent = now.toLocaleTimeString();
}

setInterval(updateTime, 1000);
updateTime();

// Voice input
voiceBtn.addEventListener('click', toggleVoiceInput);

if (recognition) {
    recognition.onstart = () => {
        isListening = true;
        voiceBtn.classList.add('active');
        voiceBtn.innerHTML = '<span class="mic-icon">🎤</span> LISTENING...';
        addMessage('Listening for your command...', 'system');
    };

    recognition.onend = () => {
        isListening = false;
        voiceBtn.classList.remove('active');
        voiceBtn.innerHTML = '<span class="mic-icon">🎤</span>';
    };

    recognition.onresult = (event) => {
        let transcript = '';
        for (let i = event.resultIndex; i < event.results.length; i++) {
            transcript += event.results[i][0].transcript;
        }
        if (transcript.trim()) {
            userInput.value = transcript;
            sendMessage();
        }
    };

    recognition.onerror = (event) => {
        console.error('Speech recognition error:', event.error);
        voiceBtn.classList.remove('active');
        voiceBtn.innerHTML = '<span class="mic-icon">🎤</span>';
        
        let errorMsg = 'Voice input error: ';
        switch(event.error) {
            case 'no-speech':
                errorMsg += 'No speech detected. Please try again.';
                break;
            case 'audio-capture':
                errorMsg += 'No microphone found. Please check your audio settings.';
                break;
            case 'not-allowed':
                errorMsg += 'Microphone access denied. Please enable microphone permissions.';
                break;
            case 'network':
                errorMsg += 'Network error. Please check your connection.';
                break;
            default:
                errorMsg += event.error;
        }
        addMessage(errorMsg, 'error');
    };
}

function toggleVoiceInput() {
    if (!recognition) {
        addMessage('Voice input is not supported in your browser. Please use Chrome, Edge, or Firefox.', 'error');
        return;
    }
    
    if (isListening) {
        recognition.stop();
    } else {
        userInput.value = '';
        try {
            recognition.start();
        } catch (e) {
            console.error('Error starting recognition:', e);
            addMessage('Error starting voice input. Please try again.', 'error');
        }
    }
}

// Send message
sendBtn.addEventListener('click', sendMessage);
userInput.addEventListener('keypress', (e) => {
    if (e.key === 'Enter') sendMessage();
});

// Clear button
clearBtn.addEventListener('click', () => {
    userInput.value = '';
    userInput.focus();
});

function sendMessage() {
    let message = userInput.value;
    
    if (message.trim() === "") return;

    // Add user message
    addMessage(message, 'user');
    userInput.value = "";

    // Send to server
    fetch("/chat/", {
        method: "POST",
        headers: {
            "Content-Type": "application/x-www-form-urlencoded",
            "X-CSRFToken": getCookie("csrftoken")
        },
        body: "message=" + encodeURIComponent(message)
    })
    .then(response => response.json())
    .then(data => {
        addMessage(data.reply, 'jarvis');
        chatBox.scrollTop = chatBox.scrollHeight;
    })
    .catch(error => {
        console.error('Error:', error);
        addMessage('ERROR: Unable to process request', 'error');
    });
}

function addMessage(text, sender) {
    const messageDiv = document.createElement('div');
    messageDiv.className = `message ${sender}-msg`;
    
    const prefix = document.createElement('span');
    prefix.className = 'msg-prefix';
    prefix.textContent = '●';
    
    const textSpan = document.createElement('span');
    textSpan.className = 'msg-text';
    
    if (sender === 'user') {
        textSpan.textContent = 'YOU // ' + text;
    } else if (sender === 'jarvis') {
        textSpan.textContent = 'JARVIS // ' + text;
    } else if (sender === 'system') {
        textSpan.textContent = 'SYSTEM // ' + text;
    } else if (sender === 'error') {
        textSpan.textContent = 'ERROR // ' + text;
    } else {
        textSpan.textContent = text;
    }
    
    messageDiv.appendChild(prefix);
    messageDiv.appendChild(textSpan);
    chatBox.appendChild(messageDiv);
    chatBox.scrollTop = chatBox.scrollHeight;
}

function getCookie(name) {
    let cookieValue = null;
    let cookies = document.cookie.split(";");

    for (let cookie of cookies) {
        cookie = cookie.trim();
        if (cookie.startsWith(name + "=")) {
            cookieValue = decodeURIComponent(cookie.substring(name.length + 1));
            break;
        }
    }
    return cookieValue;
}