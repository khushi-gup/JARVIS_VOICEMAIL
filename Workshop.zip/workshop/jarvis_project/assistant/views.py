from django.shortcuts import render

# Create your views here.
from django.shortcuts import render
from django.http import JsonResponse
from groq import Groq
from dotenv import load_dotenv
import os

load_dotenv()

client = Groq(api_key=os.getenv("GROQ_API_KEY"))

def home(request):
    return render(request, "index.html")

def chat(request):
    if request.method == "POST":
        user_message = request.POST.get("message")

        response = client.chat.completions.create(
            model="llama-3.1-8b-instant",
            messages=[
                {"role": "system", "content": "You are JARVIS, a helpful AI assistant."},
                {"role": "user", "content": user_message}
            ]
        )

        ai_reply = response.choices[0].message.content
        return JsonResponse({"reply": ai_reply})