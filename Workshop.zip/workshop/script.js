function sendMessage() {
    let input = document.getElementById("user-input");
    let message = input.value;
    let chatBox = document.getElementById("chat-box");

    if (message.trim() === "") return;

    chatBox.innerHTML += `<div class="user-msg">You: ${message}</div>`;
    input.value = "";

    fetch("/chat/", {
        method: "POST",
        headers: {
            "Content-Type": "application/x-www-form-urlencoded",
            "X-CSRFToken": getCookie("csrftoken")
        },
        body: "message=" + encodeURIComponent(message)
    })
    .then(response => response.json())
    .then(data => {
        chatBox.innerHTML += `<div class="bot-msg">JARVIS: ${data.reply}</div>`;
        chatBox.scrollTop = chatBox.scrollHeight;
    });
}

function getCookie(name) {
    let cookieValue = null;
    let cookies = document.cookie.split(";");

    for (let cookie of cookies) {
        cookie = cookie.trim();
        if (cookie.startsWith(name + "=")) {
            cookieValue = decodeURIComponent(cookie.substring(name.length + 1));
            break;
        }
    }
    return cookieValue;
}